package com.sibem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sibem.models.Prodi;

public interface ProdiRepo extends JpaRepository<Prodi, String> {

}
