package com.sibem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sibem.models.Saldo;

public interface SaldoRepo extends JpaRepository<Saldo, Integer> {

	
	
}
