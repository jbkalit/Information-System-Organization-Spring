package com.sibem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sibem.models.Jabatan;
public interface JabatanRepo extends JpaRepository<Jabatan, Integer> {

}
