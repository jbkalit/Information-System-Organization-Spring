package com.sibem.models;

public class KegiatanBEM {

}
